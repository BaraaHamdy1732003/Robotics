import serial
import time

# Change the port to match your Arduino's connection
serialDevice = serial.Serial('/dev/ttyACM0', 9600)
time.sleep(2)  # Allow Arduino time to reset

s = "L"
g = None
x = 0.0
y = 0.0

def sendCoor():
    global s, g, x, y
    with open('star (1).gcode', 'r') as file:
        for line in file:
            data = line.strip()
            if not data:  # Skip empty lines
                continue
            current_x = 0.0
            current_y = 0.0

            gxy = data.split()

            for coordinate in gxy:

                if coordinate.startswith("G0"):
                    g = "A"
                elif coordinate.startswith("G1"):
                    g = "B"

                if coordinate.startswith('X'):
                    current_x = float(coordinate[1:])
                    current_x= round(current_x, 2)

                if coordinate.startswith('Y'):
                    current_y = float(coordinate[1:])
                    current_y = round(current_y, 2)

                if "path" in coordinate:
                    s = "L"

                if "circle" in coordinate:
                    s = "C"

            if x is None or y is None or abs(current_x - x) >= 0.5 or abs(current_y - y) >= 0.5:
                serialDevice.write(f"{g} {current_x} {current_y} {s}\n".encode('utf-8'))
                print(f"Sent: {g} {current_x} {current_y} {s}")
                x = current_x
                y = current_y

                # Wait for Arduino acknowledgment
                while True:
                    if serialDevice.in_waiting > 0:
                        ack = serialDevice.readline().decode('utf-8').strip()
                        print(f"Arduino: {ack}")
                        if ack == "DONE":
                            break
    serialDevice.write("D 0 0 L".encode('utf-8'))
    print("Process finished!")

sendCoor()





